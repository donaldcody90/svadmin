<div rel="title">
   Change Duty
</div>
<div rel="body" class="contentPopup">
	<div id="response_ajax"></div>

</div>
<?php $this->load->view('_base/ajax_script'); ?>