<?php $this->load->view('_base/head'); ?>
    <h2 class="title "> Danh sách khách hàng</h2>
    <div class="gridtable" >
                    <table >
                        <tr>
                            <td>
                                Title 1
                            </td>
                            <td >
                                Title 2
                            </td>
                            <td>
                                Title 3
                            </td>
                        </tr>
                        <tr>
                            <td >
                                Row 1
                            </td>
                            <td>
                                Row 1
                            </td>
                            <td>
                                Row 1
                            </td>
                        </tr>
                        <tr>
                            <td >
                                Row 2
                            </td>
                            <td>
                                Row 2
                            </td>
                            <td>
                                Row 2
                            </td>
                        </tr>
                        <tr>
                            <td >
                                Row 2
                            </td>
                            <td>
                                Row 2
                            </td>
                            <td>
                                Row 2
                            </td>
                        </tr>
                        <tr>
                            <td >
                                Row 3
                            </td>
                            <td>
                                Row 3
                            </td>
                            <td>
                                Row 3
                            </td>
                        </tr>
                    </table>
                </div>
                
    			
    <ul class="pagination">
      <li><a href="#">&laquo;</a></li>
      <li><a href="#">1</a></li>
      <li><a class="active" href="#">2</a></li>
      <li><a href="#">3</a></li>
      <li><a href="#">4</a></li>
      <li><a href="#">5</a></li>
      <li><a href="#">6</a></li>
      <li><a href="#">7</a></li>
      <li><a href="#">&raquo;</a></li>
    </ul>

<?php $this->load->view('_base/footer'); ?>